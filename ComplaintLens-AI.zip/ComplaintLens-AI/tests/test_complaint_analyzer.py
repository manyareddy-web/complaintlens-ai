"""
Automated tests for ComplaintLens AI.

Run from the project folder with:
    python -m unittest discover -s tests -v
"""

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database  # noqa: E402
from complaint_analyzer import (  # noqa: E402
    ComplaintAnalyzer,
    InvalidComplaintError,
    extract_keywords,
    summarize,
    validate_complaint,
)


class AnalyzerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.analyzer = ComplaintAnalyzer()

    def test_payment_example_from_the_brief(self):
        r = self.analyzer.analyze("My money was deducted from my account but the payment failed.")
        self.assertEqual(r["category"], "Payment Issue")
        self.assertEqual(r["sentiment"], "Negative")
        self.assertEqual(r["priority"], "High")
        self.assertEqual(r["urgency"], "High")
        self.assertIn("refund investigation", r["recommended_action"])

    def test_hacked_account_is_critical(self):
        r = self.analyzer.analyze("My account has been hacked and money was stolen.")
        self.assertEqual(r["category"], "Account Issue")
        self.assertEqual(r["priority"], "Critical")
        self.assertIn("security team", r["recommended_action"])

    def test_delivery_issue_is_medium(self):
        r = self.analyzer.analyze(
            "My order has not arrived even though it was supposed to be delivered yesterday."
        )
        self.assertEqual(r["category"], "Delivery Issue")
        self.assertEqual(r["priority"], "Medium")

    def test_safety_problem_is_critical(self):
        r = self.analyzer.analyze("The mixer grinder makes a burning smell and sparks when switched on")
        self.assertEqual(r["priority"], "Critical")

    def test_positive_feedback_is_not_a_complaint_category(self):
        r = self.analyzer.analyze("Thank you for the quick help with my last order!")
        self.assertEqual(r["sentiment"], "Positive")
        self.assertEqual(r["category"], "Other")

    def test_keyword_example_from_the_brief(self):
        keywords = extract_keywords(
            "My credit card payment failed but the amount was deducted from my bank account."
        )
        self.assertEqual(
            keywords, ["credit card", "payment", "failed", "amount", "deducted", "bank account"]
        )

    def test_summary_is_third_person(self):
        summary = summarize("I ordered a laptop five days ago. The delivery was promised yesterday, "
                            "but I still haven't received it.")
        self.assertIn("the customer still hasn't received it", summary)

    def test_result_has_every_field(self):
        r = self.analyzer.analyze("The app keeps crashing every time I open it")
        for key in ("category", "sentiment", "priority", "urgency", "keywords",
                    "summary", "recommended_action"):
            self.assertTrue(r[key], f"{key} should not be empty")


class ValidationTests(unittest.TestCase):
    def test_empty_text_is_rejected(self):
        for bad in ("", "    ", None, 123):
            with self.assertRaises(InvalidComplaintError):
                validate_complaint(bad)

    def test_too_short_and_symbols_only_are_rejected(self):
        for bad in ("help", "!!!! ???? 12345 ...."):
            with self.assertRaises(InvalidComplaintError):
                validate_complaint(bad)

    def test_too_long_is_rejected(self):
        with self.assertRaises(InvalidComplaintError):
            validate_complaint("word " * 1000)


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self._folder = tempfile.TemporaryDirectory()
        self._original_path = database.DB_PATH
        database.DB_PATH = Path(self._folder.name) / "test.db"  # use a throw-away database
        database.init_db()

    def tearDown(self):
        database.DB_PATH = self._original_path
        self._folder.cleanup()

    def test_save_and_load(self):
        analyzer = ComplaintAnalyzer()
        result = analyzer.analyze("The delivery boy was very rude to my mother yesterday")
        new_id = database.save_complaint(result)
        df = database.load_complaints()
        self.assertEqual(len(df), 1)
        self.assertEqual(int(df.loc[0, "complaint_id"]), new_id)
        self.assertEqual(df.loc[0, "category"], result["category"])

    def test_sample_data_is_loaded_once(self):
        analyzer = ComplaintAnalyzer()
        first = database.seed_sample_data(analyzer)
        second = database.seed_sample_data(analyzer)
        self.assertGreaterEqual(first, 50)
        self.assertEqual(second, 0)


if __name__ == "__main__":
    unittest.main()
